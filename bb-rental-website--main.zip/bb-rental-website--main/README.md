# BB Rentals

BB Rentals is a React + Vite car-rental application with customer and rental-business modules. The current version stores accounts, storefronts, vehicles, and reservations in the current browser's `localStorage`.

## Modules

### User module
- Customer signup and login
- Browse the BB Rentals storefront and available vehicles
- View vehicle details and reserve dates
- View booking history and payment status

### Admin module
- Business signup and login
- Create a public storefront with 20 starter vehicles
- Manage vehicle availability and daily rates
- Review reservations, record pay-at-pickup collections, and export CSV reports

## Run locally

1. Install Node.js 20.19+ or 22.12+.
2. Install dependencies with `npm install`.
3. In VS Code, press `F5` and select **BB Rentals (Vite)** to start the app and open it in Chrome. Alternatively, start it with `npm run dev`.
4. Open the Vite URL shown in the terminal (usually `http://localhost:5173/`).

To use the VS Code Live Server extension, first run **Terminal → Run Task → Build BB Rentals for Live Server**, then choose **Go Live**. Live Server is configured to serve the compiled `dist` folder. Rebuild after code changes. For development with hot reload and reliable page refreshes on app routes, press `F5` and select **BB Rentals (Vite)** instead. Do not open the project with a `file://` URL. Login, signup, business setup, and bookings work without a database connection.

The BB Rentals storefront is initialized with example vehicles. Sample listings are for exploring the app, not real rental offers.

## Data storage limits

- Customer names, email addresses, phone numbers, account profiles, and booking records are saved in the current browser's `localStorage`.
- Data stays in the browser profile and device where it was entered. It does not sync to another browser or device.
- Clearing site data or using private browsing can remove or isolate the saved records.
- Browser `localStorage` is for demos and local projects; it is not appropriate for real customer data or production authentication.
- Vercel can host the frontend, but deploying it does not make browser records shared or backed up. A shared production service needs a configured backend and database.
- Payments are recorded manually at pick-up; this app does not process online payments. UPI customers can use the displayed UPI ID: `7386228408@ibl`.

## Deploy to Vercel

1. Push the project to GitHub and import it into Vercel, or deploy with the Vercel CLI.
2. Use the Vite defaults: build command `npm run build`, output directory `dist`.
3. `vercel.json` rewrites routes to `index.html` for React Router.
4. Open the deployed URL and test signup, business setup, and booking in that browser.

Accounts and records on the deployed website are separate from local development and from other visitors' browser profiles.

## Build

```bash
npm run build
```
